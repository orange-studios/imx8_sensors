 * Android O version driver
 *
 * REVISON HISTORY
 *
 * VERSION | DATE          | DESCRIPTION
 *
 * 3.0.0   | 05/15/2017    | MTK driver initial version
 * 3.0.1   | 06/20/2017    | fixed some logical bug
 * 3.0.2   | 07/03/2017    | add Kconfig
 * 3.0.3   | 07/05/2017    | fixed ATA gyro test bug
 * 3.0.4   | 08/25/2017    | add gyro suspend and resume operation
 * 3.0.5   | 09/25/2017    | reserved for SPI driver version
 * 3.0.6   | 09/25/2017    | fixed bugs in factory mode
 * 3.0.7   | 02/08/2018    | modified driver to be compatible with Android O
 * 3.0.8   | 04/11/2018    | add gyro turn-on time to fix VTS gyro test error
 * 3.0.9   | 05/14/2018    | fixed a compile error and add gyro flush interface
 * 3.1.0   | 05/15/2018    | optimized factory mode calibration functions
 * 3.1.1   | 07/12/2018    | optimized interrupt configuration and calibration functions
