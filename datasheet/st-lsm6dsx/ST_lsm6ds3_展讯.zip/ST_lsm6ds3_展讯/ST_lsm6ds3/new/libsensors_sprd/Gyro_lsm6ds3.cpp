/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <poll.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/select.h>
#include <cutils/log.h>
#include <string.h>
#include "GyroSensor.h"

#define LSM6DS0_GYRO_INPUT_NAME		"lsm6ds0_gyr"

#define LSM6DS0_ATTR_GROUP_NAME		"gyroscope"
#define LSM6DS0_ENABLE_ATTR_NAME	"enable_device"
#define LSM6DS0_POLLRATE_ATTR_NAME	"pollrate_ms"
#define LSM6DS0_RANGE_ATTR_NAME		"range"

#define SENSOR_GYRO_LABEL			"LSM6DS3 3-axis Gyroscope sensor"	// Label views in Android Applications
#define SENSOR_DATANAME_GYROSCOPE		"ST LSM6DS3 Gyroscope Sensor"		// Name of input device: struct input_dev->name
#define GYRO_DELAY_FILE_NAME			"gyro/polling_rate"			// name of sysfs file for setting the pollrate
#define GYRO_ENABLE_FILE_NAME			"gyro/enable"		// name of sysfs file for enable/disable the sensor state
#define GYRO_RANGE_FILE_NAME			"gyro/scale"


#define GYRO_MAX_RANGE				(2000.0f * (float)M_PI/180.0f)		// Set Max Full-scale [rad/sec]
#define GYRO_MAX_ODR				100					// Set Max value of ODR [Hz]
#define GYRO_MIN_ODR				25
#define GYRO_POWER_CONSUMPTION		4.0f					// Set sensor's power consumption [mA]
#define GYRO_DEFAULT_FULLSCALE		2000					// Set default full-scale (value depends on the driver sysfs file)
#define TO_MDPS(x)					(x / 1000000.0f)

#define FREQUENCY_TO_USECONDS(x)        (1000000 / x)

#define DPS2RAD                                        ((float)M_PI/180.0f)
#define G_SENSITIVITY                  (1.0f) //Already applied into the driver
#define GYR_UNIT_CONVERSION(value)             (value * DPS2RAD * G_SENSITIVITY / (1000.0f * 1000.0f))


/*****************************************************************************/
static struct sensor_t sSensorList[] = {
	{
		"LSM6DS3 3-axis Gyroscope sensor",
		"STMicroelectronics",
		1,
		SENSORS_GYROSCOPE_HANDLE,
		SENSOR_TYPE_GYROSCOPE,
		GYRO_MAX_RANGE,
		0.0f,
		GYRO_POWER_CONSUMPTION,
		FREQUENCY_TO_USECONDS(GYRO_MAX_ODR),
		0,
		0,
		SENSOR_STRING_TYPE_GYROSCOPE,
		"",
		40000,
		SENSOR_FLAG_CONTINUOUS_MODE,
		{}
	},
};

GyroSensor::GyroSensor() :
	SensorBase(NULL, SENSOR_DATANAME_GYROSCOPE),
		mEnabled(0), mDelay(-1), mInputReader(32), mHasPendingEvent(false),
		mSensorCoordinate()
{
	mPendingEvent.version = sizeof(sensors_event_t);
	mPendingEvent.sensor = ID_G;
	mPendingEvent.type = SENSOR_TYPE_GYROSCOPE;
	memset(mPendingEvent.data, 0, sizeof(mPendingEvent.data));

	if (data_fd >= 0) {
        strcpy(input_sysfs_path, "/sys/class/input/");
        strcat(input_sysfs_path, input_name);
        //strcat(input_sysfs_path, "/device/device/");
        strcat(input_sysfs_path, "/device/");
        //strcat(input_sysfs_path, LSM6DS0_ATTR_GROUP_NAME);
        //strcat(input_sysfs_path, "/");
        input_sysfs_path_len = strlen(input_sysfs_path);
        ALOGD("jonny GyroSensor: sysfs_path=%s", input_sysfs_path);
    } else {
        input_sysfs_path[0] = '\0';
        input_sysfs_path_len = 0;
    }
}

GyroSensor::~GyroSensor()
{
	if (mEnabled) {
		setEnable(0, 0);
	}

	close_device();
}

/*
int GyroSensor::setFullScale(int32_t handle, int value)
{
    int err = -1;
    int fd;
    char buf[6];

    ALOGE("GyroSensor::setFullScale handle=%d, value=%d\n", handle, value);
    if(value <= 0)
        return err;
    else
        err = 0;

    if (handle != ID_G) {
        ALOGE("GyroSensor: Invalid handle (%d)", handle);
        return -EINVAL;
    }

    strcpy(&input_sysfs_path[input_sysfs_path_len], LSM6DS0_RANGE_ATTR_NAME);
    sprintf(buf,"%d", value);
    err = write_sys_attribute(input_sysfs_path, buf, sizeof(buf));
    if(err >= 0) {
        err = 0;
    }
    return err;
}
*/

int GyroSensor::setInitialState()
{
	struct input_absinfo absinfo;
        int clockid = CLOCK_BOOTTIME;

//	if (mEnabled) {
	if(1){
		if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_ACCEL_X), &absinfo)) {
			mPendingEvent.gyro.x = GYR_UNIT_CONVERSION(absinfo.value);
		}
		if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_ACCEL_Y), &absinfo)) {
			mPendingEvent.gyro.y = GYR_UNIT_CONVERSION(absinfo.value);
		}
		if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_ACCEL_Z), &absinfo)) {
			mPendingEvent.gyro.z = GYR_UNIT_CONVERSION(absinfo.value);
		}
	}

        if (!ioctl(data_fd, EVIOCSCLOCKID, &clockid))
        {
            ALOGD("GyroSensor: set EVIOCSCLOCKID = %d\n", clockid);
        }
        else
        {
            ALOGE("GyroSensor: set EVIOCSCLOCKID failed \n");
        }

	//setFullScale(SENSORS_GYROSCOPE_HANDLE, GYRO_DEFAULT_FULLSCALE);
	return 0;
}

bool GyroSensor::hasPendingEvents() const
{
	return mHasPendingEvent;
}

int GyroSensor::setEnable(int32_t handle, int enabled)
{
	int err = 0;
//	int opDone = 0;

	/* handle check */
	if (handle != ID_G) {
		ALOGE("GyroSensor: Invalid handle (%d)", handle);
		return -EINVAL;
	}

	strcpy(&input_sysfs_path[input_sysfs_path_len], GYRO_ENABLE_FILE_NAME);
	ALOGD("jonny GyroSensor enable: sysfs_path=%s", input_sysfs_path);
	if (mEnabled <= 0) {
		if (enabled) {
            setInitialState();
			err = write_sys_attribute(input_sysfs_path, "1", 1); //"1" = enable
			if (err != 0) {
				return err;
			}
			ALOGD("GyroSensor LSM6DS3: Control set enable");
			//	opDone = 1;
		}
	} else if (mEnabled == 1) {
		if (!enabled) {
			err = write_sys_attribute(input_sysfs_path, "0", 1); //"0" = disable
			if (err != 0) {
				return err;
			}
			ALOGD("GyroSensor LSM6DS3: Control set disable");
		}
	}
	if (err != 0) {
		ALOGE("GyroSensor: IOCTL failed (%s)", strerror(errno));
		return err;
	}
//	if (opDone) {
//		ALOGD("GyroSensor: Control set %d", enabled);
//		setInitialState();
//	}

	if (enabled) {
		mEnabled++;
		if (mEnabled > 32767)
			mEnabled = 32767;
	} else {
		mEnabled--;
		if (mEnabled < 0)
			mEnabled = 0;
	}
	ALOGD("GyroSensor: mEnabled = %d", mEnabled);

	return err;
}

int GyroSensor::setDelay(int32_t handle, int64_t delay_ns)
{
	int err = 0;
	int ms;
	char buf[6];

	/* handle check */
	if (handle != ID_G) {
		ALOGE("GyroSensor: Invalid handle (%d)", handle);
		return -EINVAL;
	}

	//if (mDelay != delay_ns) {
		ms = delay_ns / 1000000;
		mDelay = delay_ns;
		if (ms<10) {
			ms = 10;
			mDelay = ms * 1000000;
		}
		ALOGE("GyroSensor: setDelay = (%d)ms", ms);
		sprintf(buf, "%d", ms);
		strcpy(&input_sysfs_path[input_sysfs_path_len], GYRO_DELAY_FILE_NAME);
		ALOGD("jonny GyroSensor setdelay: sysfs_path=%s", input_sysfs_path);
		err = write_sys_attribute(input_sysfs_path, buf, sizeof(buf)); //
	//}

	return err;
}

int64_t GyroSensor::getDelay(int32_t handle)
{
	ALOGE("GyroSensor: getDelay = (%d)ns", mDelay);
	return (handle == ID_G) ? mDelay : 0;
}

int GyroSensor::getEnable(int32_t handle)
{
	return (handle == ID_G) ? mEnabled : 0;
}

int GyroSensor::readEvents(sensors_event_t * data, int count)
{
	if (count < 1)
		return -EINVAL;

	if (mHasPendingEvent) {
		mHasPendingEvent = false;
		mPendingEvent.timestamp = getTimestamp();
		*data = mPendingEvent;
		return mEnabled ? 1 : 0;
	}

	ssize_t n = mInputReader.fill(data_fd);
	if (n < 0)
		return n;

	int numEventReceived = 0;
	input_event const *event;
	static float gyro_latest_x;
	static float gyro_latest_y;
	static float gyro_latest_z;

	while (count && mInputReader.readEvent(&event)) {
		int type = event->type;
		if (type == EVENT_TYPE_GYRO) {
			float value = event->value;
			if (event->code == EVENT_TYPE_GYRO_X) {
				//mPendingEvent.gyro.x = GYR_UNIT_CONVERSION(value);
				gyro_latest_x = GYR_UNIT_CONVERSION(value);
			} else if (event->code == EVENT_TYPE_GYRO_Y) {
				//mPendingEvent.gyro.y = GYR_UNIT_CONVERSION(value);
				gyro_latest_y = GYR_UNIT_CONVERSION(value);
			} else if (event->code == EVENT_TYPE_GYRO_Z) {
				//mPendingEvent.gyro.z = GYR_UNIT_CONVERSION(value);
				gyro_latest_z = GYR_UNIT_CONVERSION(value);
			}
		} else if (type == EV_SYN) {
			mPendingEvent.timestamp = timevalToNano(event->time);
			if (mEnabled) {
				mPendingEvent.gyro.x = gyro_latest_x *(-1);
				mPendingEvent.gyro.y = gyro_latest_y;
				mPendingEvent.gyro.z = gyro_latest_z *(-1);
				mSensorCoordinate.coordinate_data_convert(
						mPendingEvent.gyro.v, INSTALL_DIR);
				*data++ = mPendingEvent;
				count--;
				numEventReceived++;
			}
		} else {
			ALOGE("GyroSensor: unknown event (type=%d, code=%d)",
			      type, event->code);
		}
		mInputReader.next();
	}

	return numEventReceived;
}

int GyroSensor::populateSensorList(struct sensor_t *list)
{
	memcpy(list, sSensorList, sizeof(struct sensor_t) * numSensors);
	return numSensors;
}
