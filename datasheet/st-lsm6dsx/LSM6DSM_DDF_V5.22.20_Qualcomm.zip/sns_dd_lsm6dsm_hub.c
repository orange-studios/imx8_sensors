/******************** (C) COPYRIGHT 2018 STMicroelectronics ********************
 *
 * File Name         : sns_dd_lsm6dsm_hub.c
 * Authors           : Karimuddin Sayed
 * Version           : V 5.22.20
 * Date              : 5/16/2018
 * Description       : LSM6DSM driver source file
 *
 ********************************************************************************
 * Copyright (c) 2018, STMicroelectronics.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *     2. Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     3. Neither the name of the STMicroelectronics nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *******************************************************************************/
#include "sns_dd_lsm6dsm.h"
//sns_ddf_driver_if_s sns_dd_lsm6dsm_esp_if;
#if LSM6DSM_ENABLE_HUB


/* LSM6DSM embedded registers */
#define STM_LSM6DSM_SLV0_ADDR                    (0x02)
#define STM_LSM6DSM_SLV0_SUBADDR_ADDR            (0x03)
#define STM_LSM6DSM_SLV0_CONFIG_ADDR             (0x04)
#define STM_LSM6DSM_SLV1_ADDR                    (0x05)
#define STM_LSM6DSM_SLV1_SUBADDR_ADDR            (0x06)
#define STM_LSM6DSM_SLV1_CONFIG_ADDR             (0x07)
#define STM_LSM6DSM_SLV2_ADDR                    (0x08)
#define STM_LSM6DSM_SLV2_SUBADDR_ADDR            (0x09)
#define STM_LSM6DSM_SLV2_CONFIG_ADDR             (0x0A)
#define STM_LSM6DSM_SLV3_ADDR                    (0x0B)
#define STM_LSM6DSM_SLV3_SUBADDR_ADDR            (0x0C)
#define STM_LSM6DSM_SLV3_CONFIG_ADDR             (0x0D)

#define STM_LSM6DSM_DATAWRITE_SRC_MODE_SUB_SLV0  (0x0e)
#define STM_LSM6DSM_MASTER_CFG                   (0x1A)
#define STM_LSM6DSM_HUB_HAVE_ONE_SENSOR          (0x00)
#define STM_LSM6DSM_HUB_HAVE_TWO_SENSOR          (0x10)

#define STM_LSM6DSM_SLAVE_ODR_NUM                ARR_SIZE(slave_odr)
#if LSM6DSM_SLAVE_AK09916
#define INTERNAL_PULLUP 1
#define STM_LSM6DSM_SLAVE_1_I2C_ADDR_8BIT          AK09916_I2C_ADDRESS
#define STM_LSM6DSM_SLAVE_1_WAI_REG_ADDR           AK09916_WAI_ADDR
#define STM_LSM6DSM_SLAVE_1_WAI_ID                 AK09916_WAI_ID
#define STM_LSM6DSM_SLAVE_1_RESET_ADDR             AK09916_CNTL3_ADDR
#define STM_LSM6DSM_SLAVE_1_POWER_ADDR             STM_LSM6DSM_SLAVE_1_ODR_ADDR
#define STM_LSM6DSM_SLAVE_1_POWER_ON_VALUE         AK09916_POWER_ON_VALUE
#define STM_LSM6DSM_SLAVE_1_POWER_OFF_VALUE        AK09916_POWER_OFF_VALUE
#define STM_LSM6DSM_SLAVE_1_ODR_ADDR               AK09916_CNTL2_ADDR
#define STM_LSM6DSM_SLAVE_1_OUTDATA_ADDR           AK09916_OUTDATA_ADDR
#define STM_LSM6DSM_SLAVE_1_STATUS_ADDR            AK09916_STATUS1_ADDR
#define STM_LSM6DSM_SLAVE_1_SP_STATUS_ADDR         AK09916_STATUS2_ADDR
#define STM_LSM6DSM_SLAVE_1_OUTDATA_LEN            AK09916_OUTDATA_LEN
#define STM_LSM6DSM_SALVE_1_SSTVT                  AK09916_SSTVT
#define STM_LSM6DSM_SLAVE_MIN_RANGE                FX_FLTTOFIX_Q16(AK09916_MIN_RANGE / 1000.0f)
#define STM_LSM6DSM_SLAVE_MAX_RANGE                FX_FLTTOFIX_Q16(AK09916_MAX_RANGE / 1000.0f)
#define STM_LSM6DSM_SLAVE_SENSOR_NAME              AK09916_NAME
#define STM_LSM6DSM_SLAVE_SENSOR_VENDOR            AK09916_VENDOR
#define STM_LSM6DSM_SLAVE_SENSOR_MODEL             AK09916_MODEL

#define AK09916_NAME                                  "Magnetometer"
#define AK09916_VENDOR                                "AKM"
#define AK09916_MODEL                                 "AK09916"
#define AK09916_SSTVT                                 (0.0015f) //gauss
#define AK09916_MIN_RANGE                             (-51600) //mgauss
#define AK09916_MAX_RANGE                             (51600) //mgauss
#define AK09916_I2C_ADDRESS                           (0x0c)        /* SDO = 1 : 0x1e --- SDO = 0 : 0x1c */

/* AK09916 registers */
#define AK09916_WAI_ADDR                              (0x00)
#define AK09916_WAI_ID                                (0x48)
#define AK09916_CNTL2_ADDR                            (0x31)
#define AK09916_CNTL3_ADDR                            (0x32)
#define AK09916_OUTDATA_ADDR                          (0x11)
#define AK09916_STATUS1_ADDR                          (0x10)
#define AK09916_STATUS2_ADDR                          (0x18)

#define AK09916_POWER_ON_VALUE                        (0x00) //SDR=1 low noise mode
#define AK09916_POWER_OFF_VALUE                       (0x00)


#define AK09916_CNTL2_BASE                           ((0 << 7) |    /* (0) */ \
                                                      (0 << 6) |    /* (0) */ \
                                                      (0 << 5) |    /* (0) */ \
                                                      (0 << 4) |    /* MODE4 */ \
                                                      (0 << 3) |    /* MODE3 */ \
                                                      (0 << 2) |    /* MODE2 */ \
                                                      (0 << 1) |    /* MODE1 */ \
                                                      (0 << 0))     /* MODE0 */

static sns_ddf_odr_t slave_odr[] = {1, 13, 26, 52, 104};
static sns_ddf_odr_t slave_odr_regValues[] = {0x0C, 0x02, 0x04, 0x06, 0x08};
#elif LSM6DSM_SLAVE_LIS2MDL
#define INTERNAL_PULLUP 1
#define STM_LSM6DSM_SLAVE_1_I2C_ADDR_8BIT          LIS2MDL_I2C_ADDRESS
#define STM_LSM6DSM_SLAVE_1_WAI_REG_ADDR           LIS2MDL_WAI_ADDR
#define STM_LSM6DSM_SLAVE_1_WAI_ID                 LIS2MDL_WAI_ID
#define STM_LSM6DSM_SLAVE_1_RESET_ADDR             LIS2MDL_CNTL3_ADDR
#define STM_LSM6DSM_SLAVE_1_POWER_ADDR             STM_LSM6DSM_SLAVE_1_ODR_ADDR
#define STM_LSM6DSM_SLAVE_1_POWER_ON_VALUE         LIS2MDL_POWER_ON_VALUE
#define STM_LSM6DSM_SLAVE_1_POWER_OFF_VALUE        LIS2MDL_POWER_OFF_VALUE
#define STM_LSM6DSM_SLAVE_1_ODR_ADDR               LIS2MDL_CNTLA_ADDR
#define STM_LSM6DSM_SLAVE_1_OUTDATA_ADDR           LIS2MDL_OUTDATA_ADDR
#define STM_LSM6DSM_SLAVE_1_STATUS_ADDR            LIS2MDL_STATUS_ADDR
#define STM_LSM6DSM_SLAVE_1_OUTDATA_LEN            LIS2MDL_OUTDATA_LEN
#define STM_LSM6DSM_SALVE_1_SSTVT                  LIS2MDL_SSTVT
#define STM_LSM6DSM_SLAVE_MIN_RANGE                FX_DIV_Q16(FX_CONV_Q16((int32_t)LIS2MDL_MIN_RANGE,0), FX_CONV_Q16((int32_t)1000,0))
#define STM_LSM6DSM_SLAVE_MAX_RANGE                FX_DIV_Q16(FX_CONV_Q16((int32_t)LIS2MDL_MAX_RANGE,0), FX_CONV_Q16((int32_t)1000,0))
#define STM_LSM6DSM_SLAVE_SENSOR_NAME              LIS2MDL_NAME
#define STM_LSM6DSM_SLAVE_SENSOR_VENDOR            LIS2MDL_VENDOR
#define STM_LSM6DSM_SLAVE_SENSOR_MODEL             LIS2MDL_MODEL

#define LIS2MDL_NAME                                  "Magnetometer"
#define LIS2MDL_VENDOR                                "STMicroelectronics"
#define LIS2MDL_MODEL                                 "LIS2MDL"
#define LIS2MDL_SSTVT                                 (0.0015f) //gauss
#define LIS2MDL_MIN_RANGE                             (-50000) //mgauss
#define LIS2MDL_MAX_RANGE                             (50000) //mgauss
#define LIS2MDL_I2C_ADDRESS                           (0x1E)

/* AK09916 registers */
#define LIS2MDL_WAI_ADDR                              (0x4F)
#define LIS2MDL_WAI_ID                                (0x40)
#define LIS2MDL_CNTLA_ADDR                            (0x60)
#define LIS2MDL_CNTLC_ADDR                            (0x62)
#define LIS2MDL_OUTDATA_ADDR                          (0x68)
#define LIS2MDL_STATUS_ADDR                           (0x67)

#define LIS2MDL_POWER_ON_VALUE                        (0x80)
#define LIS2MDL_POWER_OFF_VALUE                       (0x00)

static sns_ddf_odr_t slave_odr[] = {13, 26, 52, 104};
static sns_ddf_odr_t slave_odr_regValues[] = {0x00, 0x04, 0x08, 0x0C};
#endif /* LSM6DSM_I2C_MASTER_AK09916 */
#define MAX_SLAVE_CHANNELS 4
enum {
  SLAVE_0,
  SLAVE_1,
  SLAVE_2,
  SLAVE_3
};

struct {
  uint8_t slave_id;
  uint8_t slave_addr;
  uint8_t slave_sub_addr;
  uint8_t slave_conf_addr;
} slave_reg_info[] =
{
  {SLAVE_0, STM_LSM6DSM_SLV0_ADDR, STM_LSM6DSM_SLV0_SUBADDR_ADDR, STM_LSM6DSM_SLV0_CONFIG_ADDR},
  {SLAVE_1, STM_LSM6DSM_SLV1_ADDR, STM_LSM6DSM_SLV1_SUBADDR_ADDR, STM_LSM6DSM_SLV1_CONFIG_ADDR},
  {SLAVE_2, STM_LSM6DSM_SLV2_ADDR, STM_LSM6DSM_SLV2_SUBADDR_ADDR, STM_LSM6DSM_SLV2_CONFIG_ADDR},
  {SLAVE_3, STM_LSM6DSM_SLV3_ADDR, STM_LSM6DSM_SLV3_SUBADDR_ADDR, STM_LSM6DSM_SLV3_CONFIG_ADDR},
};

enum {
  STM_LSM6DSM_HUB_WRITE_OP,
  STM_LSM6DSM_HUB_READ_OP,
  STM_LSM6DSM_HUB_READ_ONCE_OP,
};
enum {
  CONTINUOUS,
  ONE_SHOT,
};

typedef struct {
  bool src_cond;
  uint8_t src_cond_reg;
} channel_read_info_t;

typedef struct {
  bool write_once;
  uint8_t write_value;
} channel_write_info_t;

typedef struct {
  uint8_t channel;
  uint8_t reg;
  uint8_t mode;  // read or write
  union {
    channel_read_info_t read_info;
    channel_write_info_t write_info;
  } channel_rw_info;
  uint8_t no_ops; //num of read operations
} slave_channel_config;

struct {
  uint8_t num_of_channels;
  uint8_t slave_mode;
  slave_channel_config slave_channels[MAX_SLAVE_CHANNELS];
} slave_config[] =
{
#if LSM6DSM_SLAVE_AK09916
  { 3,
    CONTINUOUS,
    {
      {SLAVE_0, STM_LSM6DSM_SLAVE_1_SP_STATUS_ADDR, STM_LSM6DSM_HUB_READ_OP, { .read_info = {true, STM_LSM6DSM_SLAVE_1_STATUS_ADDR}}, 7},
      {SLAVE_1, STM_LSM6DSM_SLAVE_1_STATUS_ADDR, STM_LSM6DSM_HUB_READ_OP, { .read_info = {false, 0}}, 7},
      {SLAVE_2, STM_LSM6DSM_SLAVE_1_SP_STATUS_ADDR, STM_LSM6DSM_HUB_READ_OP, { .read_info = {false, 0}}, 1},
    },
  },
#elif LSM6DSM_SLAVE_LIS2MDL
{
  { 1,
    CONTINUOUS,
    {
      {SLAVE_0, STM_LSM6DSM_SLAVE_1_OUTDATA_ADDR, STM_LSM6DSM_HUB_READ_OP, {.read_info = {false, 0}}, STM_LSM6DSM_SLAVE_1_OUTDATA_LEN},
    },
  },
#endif
};

#define SENSOR_HZ_RATE_TO_US(x)                       (1000000UL / x)

static uint8_t stm_lsm6dsm_slv_axis_dflt[3] = {1, 2, 3};

static void sns_dd_lsm6dsm_enable_slaveAccess(
    sns_ddf_handle_t dd_handle,
    bool enable)
{
  uint8_t reg = STM_LSM6DSM_FUNC_CFG_ACCESS_ADDR;
  uint8_t val = STM_LSM6DSM_FUNC_CFG_ACCESS_BASE;
  if(enable)
    val |= STM_LSM6DSM_ENABLE_FUNC_CFG_ACCESS;

  sns_dd_lsm6dsm_write_reg(dd_handle, reg, &val, 1, 0xFF);
}


#if DUMP_REGISTER_DATA
static void sns_dd_lsm6dsm_dump_slaveconfig(
    sns_ddf_handle_t dd_handle)
{
  sns_dd_lsm6dsm_state_t *state = sns_dd_lsm6dsm_get_state(dd_handle);
  uint8_t value[13] = {0};
  uint8_t rw_bytes = 0;
  int i;
  sns_ddf_read_port(state->port_handle, STM_LSM6DSM_SLV0_ADDR, value, 13, &rw_bytes);
  for(i=0;i<13;i++)
    LSM6DSM_MSG_2(LOW, "reg 0x%x = 0x%x", 0x02+i, value[i]);

}
#endif

//set slave sub reg address to read/write
//value
//rw=0 write rw=1 read
//num of consecutive reads/writes
static void sns_dd_lsm6dsm_setSlaveReg(
    sns_ddf_handle_t dd_handle,
    uint8_t slave_id,
    uint8_t reg_addr,
    uint8_t rw,
    void* rw_info,
    uint8_t mul_op)

{
  //enable slave with slave i2c address
  //0x01= 0x80
  //0x02 = AKM slave address | rw_bit;
  //0x03 = who_am_i - akm reg address to read/write
  //0x04 = decimation | no of ext sensors | src_mode | no of r/w operations
  //0x07 = write_once if writing
  //0x01 = 0 disable sensor hub access
  //
  //
  uint8_t reg[7] = {0};
  uint8_t val[7] = {0};

#if DUMP_REGISTER_DATA
  LSM6DSM_MSG_0(LOW, "E::set slave reg");
  sns_dd_lsm6dsm_dump_slaveconfig(dd_handle);
#endif
  reg[1] = slave_reg_info[slave_id].slave_addr;
  val[1] = (STM_LSM6DSM_SLAVE_1_I2C_ADDR_8BIT << 1) | rw;
  reg[2] = slave_reg_info[slave_id].slave_sub_addr;
  val[2] = reg_addr;
  reg[3] = slave_reg_info[slave_id].slave_conf_addr;
  val[3] = (rw == STM_LSM6DSM_HUB_READ_OP) ? (mul_op & 0x07) : 0;

  sns_dd_lsm6dsm_write_reg(dd_handle, reg[1], &val[1], 2, 0xFF);
  if(STM_LSM6DSM_HUB_WRITE_OP == rw) {
    //write can be done only with slave0, so not needed this check
    val[3] |= STM_LSM6DSM_HUB_HAVE_TWO_SENSOR;

    sns_dd_lsm6dsm_write_reg(dd_handle, reg[3], &val[3], 1, 0xFF);
    channel_write_info_t* write_info = (channel_write_info_t*) rw_info;
    reg[4] = STM_LSM6DSM_DATAWRITE_SRC_MODE_SUB_SLV0;
    val[4] = write_info->write_value;
    sns_dd_lsm6dsm_write_reg(dd_handle, reg[4], &val[4], 1, 0xFF);
    reg[5] = STM_LSM6DSM_SLV1_CONFIG_ADDR;
    val[5] = (write_info->write_once) ? 0x20 : 0x00 ; //write once only when writing
    sns_dd_lsm6dsm_write_reg(dd_handle, reg[5], &val[5], 1, 0x20);
  } else {
    sns_dd_lsm6dsm_write_reg(dd_handle, reg[3], &val[3], 1, 0xF7);
    channel_read_info_t* read_info = (channel_read_info_t*) rw_info;
    if((read_info->src_cond) &&  (slave_id == SLAVE_0)) {
      val[4] = 0x08;
      sns_dd_lsm6dsm_write_reg(dd_handle, slave_reg_info[slave_id].slave_conf_addr, &val[4], 1, 0x08);
      reg[5] = STM_LSM6DSM_DATAWRITE_SRC_MODE_SUB_SLV0;
      val[5] = read_info->src_cond_reg;
      sns_dd_lsm6dsm_write_reg(dd_handle, reg[5], &val[5], 1, 0xFF);
    }
    reg[6] = STM_LSM6DSM_SLV1_CONFIG_ADDR;
    val[6] = 0x00;
    sns_dd_lsm6dsm_write_reg(dd_handle, reg[6], &val[6], 1, 0x20);
  }
#if DUMP_REGISTER_DATA
  LSM6DSM_MSG_0(LOW, "EX::set slave reg");
  sns_dd_lsm6dsm_dump_slaveconfig(dd_handle);
#endif
}

sns_ddf_status_e sns_dd_lsm6dsm_hub_reset(
    sns_ddf_handle_t dd_handle)
{
  uint8_t reg[2] = {0};
  uint8_t val[2] = {0};
  sns_dd_lsm6dsm_state_t *state = sns_dd_lsm6dsm_get_state(dd_handle);
  //enable func_en
  LSM6DSM_MSG_0(LOW, "HUB_SET_RESET:: ");
  reg[0] = STM_LSM6DSM_MASTER_CFG;
#if INTERNAL_PULLUP
  val[0] = 0x08; //using internal pull up
#else
  val[0] = 0x00; //using external pull up
#endif
  //if master is enabled, disable master
  //if acc is enabled because of
  sns_dd_lsm6dsm_write_reg(dd_handle, reg[0], &val[0], 1, 0x09);
  state->hub_info.intp_status = false;
  state->hub_info.master_rate_idx = -1;
  state->hub_info.sample_cnt = 0;
  state->hub_info.slv_data.samples = NULL;
  state->hub_info.dec = 1;
  state->hub_info.wmk = 0;
  state->hub_info.odr_settled_ts = sns_ddf_get_timestamp();
  state->hub_info.stream_stable = false;
  return SNS_DDF_SUCCESS;
}

static void sns_ddf_lsm6dsm_enable_master(sns_ddf_handle_t dd_handle,
    bool enable)
{
  sns_dd_lsm6dsm_state_t *state = sns_dd_lsm6dsm_get_state(dd_handle);
  uint8_t reg[2] = {0};
  uint8_t val[2] = {0};

  reg[0] = STM_LSM6DSM_REG_CTRL10_C ;
  val[0] = (enable) ? 0x04: 0x0; //FUNC_EN bit
#if LSM6DSM_ENABLE_ESP
  if(enable || !state->esp_info.esp_enabled)
#else
  if(enable)
#endif
    sns_dd_lsm6dsm_write_reg(dd_handle, reg[0], &val[0], 1, 0x04);

  reg[0] = STM_LSM6DSM_MASTER_CFG;
  val[0] = (enable) ? 0x01: 0x0; //master on/off
  sns_dd_lsm6dsm_write_reg(dd_handle, reg[0], &val[0], 1, 0x01);

}

static void sns_ddf_lsm6dsm_rwSlaveRegister(sns_ddf_handle_t dd_handle,
    uint8_t addr,
    uint8_t rw,
    void* rw_info,
    uint8_t* value, //used only incase of read, returning some value to caller
    uint8_t no_op)
{
  sns_dd_lsm6dsm_state_t *state = sns_dd_lsm6dsm_get_state(dd_handle);
  //int8_t new_rate_idx = -1,
  int8_t cur_acc_rate_idx = state->acc_cur_rate_idx;
  uint32_t delay_us = 0;
  uint8_t rw_bytes = 0;
  LSM6DSM_MSG_2(LOW, "E-rwSlaveReg ts (%u) addr (0x%x) ", sns_ddf_get_timestamp(), addr);

  sns_ddf_lsm6dsm_enable_master(dd_handle, false);

  sns_dd_lsm6dsm_enable_slaveAccess(dd_handle, true);
  if(rw == STM_LSM6DSM_HUB_READ_ONCE_OP)
    sns_dd_lsm6dsm_setSlaveReg(dd_handle, SLAVE_0, addr, STM_LSM6DSM_HUB_READ_OP, rw_info, no_op);
  else
    sns_dd_lsm6dsm_setSlaveReg(dd_handle, SLAVE_0, addr, rw, rw_info, no_op);

  sns_dd_lsm6dsm_enable_slaveAccess(dd_handle, false);

  sns_ddf_lsm6dsm_enable_master(dd_handle, true);

  //turn on only acc
  if(cur_acc_rate_idx < 0) {
    sns_dd_acc_lsm6dsm_set_datarate(dd_handle,
        STM_LSM6DSM_ODR104);
  }
  delay_us = SENSOR_HZ_RATE_TO_US(state->odr_list[state->acc_cur_rate_idx]);
  sns_ddf_delay(delay_us + 5000); //wait for triggering
  sns_ddf_lsm6dsm_enable_master(dd_handle, false);

  if((rw == STM_LSM6DSM_HUB_READ_ONCE_OP) && (value)) {
    sns_ddf_read_port(state->port_handle, STM_LSM6DSM_REG_SENSOR_HUB1, value, no_op, &rw_bytes);
  }
  if(cur_acc_rate_idx < 0)
    sns_dd_acc_lsm6dsm_set_datarate(dd_handle,
        -1);

  LSM6DSM_MSG_2(LOW, "EX-rwSlaveReg ts (%u) addr (0x%x) ", sns_ddf_get_timestamp(), addr);
}


void sns_dd_lsm6dsm_config_slaveChannels(sns_ddf_handle_t dd_handle)
{
  uint8_t mode = CONTINUOUS;
  sns_dd_lsm6dsm_enable_slaveAccess(dd_handle, true);

  for(int i=0; i<slave_config[mode].num_of_channels; i++) {
    slave_channel_config* sc_info = &slave_config[mode].slave_channels[i];
    sns_dd_lsm6dsm_setSlaveReg(dd_handle, sc_info->channel, sc_info->reg, sc_info->mode, (void *)&sc_info->channel_rw_info, sc_info->no_ops);
  }
  //update slave channels
  uint8_t num_of_slave_channels = (slave_config[mode].num_of_channels -1) << 4;
  sns_dd_lsm6dsm_write_reg(dd_handle, STM_LSM6DSM_SLV0_CONFIG_ADDR, &num_of_slave_channels, 1, 0x30);
  LSM6DSM_MSG_2(LOW, "config slave channels no_of_channels=%d value = 0x%x", slave_config[mode].num_of_channels, num_of_slave_channels);

  sns_dd_lsm6dsm_enable_slaveAccess(dd_handle, false);

}
sns_ddf_status_e sns_ddf_lsm6dsm_hub_set_slaveRate(sns_ddf_handle_t dd_handle, sns_ddf_odr_t rate, uint8_t rate_idx)
{
  sns_dd_lsm6dsm_state_t *state = sns_dd_lsm6dsm_get_state(dd_handle);
  int8_t acc_cur_rate_idx = state->acc_cur_rate_idx;
  int8_t gyr_cur_rate_idx = state->gyr_cur_rate_idx;
  sns_ddf_status_e status = SNS_DDF_SUCCESS;
  sns_ddf_odr_t new_rate;
  int8_t new_rate_idx = -1;
  channel_write_info_t write_info;
  write_info.write_once = true;
  if(rate == 0) {
    if(state->hub_info.cur_rate) {
      write_info.write_value = STM_LSM6DSM_SLAVE_1_POWER_OFF_VALUE;
      sns_ddf_lsm6dsm_rwSlaveRegister(dd_handle, STM_LSM6DSM_SLAVE_1_POWER_ADDR, STM_LSM6DSM_HUB_WRITE_OP, &write_info, NULL, 1);
      //set cur rate  so its been used in calculating effective rate and wmk
      state->hub_info.cur_rate = rate;
      if((state->fifo_info.fifo_enabled & SLAVE_FIFO_BM)) {
        status = sns_dd_lsm6dsm_disable_fifo(dd_handle, LSM6DSM_SLAVE_SENSOR);
      }
      state->hub_info.master_rate_idx = -1;
    }
  } else if(state->hub_info.cur_rate != rate) {
#if LSM6DSM_SLAVE_AK09916
    write_info.write_value = 0x80; // fifo mode
#endif
    //write control register with odr value
    write_info.write_value |= STM_LSM6DSM_SLAVE_1_POWER_ON_VALUE | slave_odr_regValues[rate_idx];
    sns_ddf_lsm6dsm_rwSlaveRegister(dd_handle, STM_LSM6DSM_SLAVE_1_POWER_ADDR, STM_LSM6DSM_HUB_WRITE_OP, &write_info, NULL, 1);

    state->hub_info.cur_rate = rate;

    sns_dd_lsm6dsm_match_odr(dd_handle,
        rate,
        &new_rate,
        &state->hub_info.master_rate_idx);

    //TODO:: assuming acc and gyro run with same rate
    //update the logic at other places to make sure
    //acc and gyro run with same rate
    new_rate_idx = sns_dd_lsm6dsm_get_max_rate(dd_handle);
    if(new_rate_idx != acc_cur_rate_idx) {
      if(state->fifo_info.fifo_enabled)
        sns_dd_lsm6dsm_stop_streaming(dd_handle, true);
      else
        sns_dd_lsm6dsm_stop_streaming(dd_handle, false);
    }

    sns_dd_lsm6dsm_config_slaveChannels(dd_handle);

    sns_ddf_lsm6dsm_enable_master(dd_handle, true);

    if(new_rate_idx != acc_cur_rate_idx)
      sns_dd_lsm6dsm_start_streaming(dd_handle);

    if(state->fifo_info.fifo_enabled) {
      if(state->acc_desired_rate_idx >= 0)
        state->data_intp.acc_intp_status = true;
      if(state->gyr_desired_rate_idx >= 0)
        state->data_intp.gyr_intp_status = true;
    }
    if((acc_cur_rate_idx != state->acc_cur_rate_idx) &&
        (state->acc_desired_rate_idx >= 0))
      sns_dd_lsm6dsm_send_event_smgr(dd_handle,
          SNS_DDF_SENSOR_ACCEL,
          SNS_DDF_SENSOR_ACCEL,
          SNS_DDF_EVENT_ODR_CHANGED);
    if((gyr_cur_rate_idx != state->gyr_cur_rate_idx) &&
        (state->gyr_desired_rate_idx >= 0))
      sns_dd_lsm6dsm_send_event_smgr(dd_handle,
          SNS_DDF_SENSOR_GYRO,
          SNS_DDF_SENSOR_GYRO,
          SNS_DDF_EVENT_ODR_CHANGED);
    //2 sample turn on time
    state->hub_info.odr_settled_ts = sns_ddf_get_timestamp() + 2 * sns_ddf_convert_usec_to_tick(1000000 / rate);
    state->hub_info.stream_stable = false;
    LSM6DSM_MSG_3(LOW, "set_hub_rate rate (%d) cur_time (%u) odr_settled_ts (%u)", rate, sns_ddf_get_timestamp(), state->hub_info.odr_settled_ts);
  }
  return status;
}
/**
* @brief Probes for an LSM6DSM part.
*
* Refer to sns_ddf_driver_if.h for definition.
*/
sns_ddf_status_e sns_dd_lsm6dsm_hub_probe(
    sns_ddf_device_access_s* device_info,
    sns_ddf_handle_t port_handle,
    sns_ddf_memhandler_s*    memhandler,
    uint32_t*                num_sensors,
    sns_ddf_sensor_e**       sensors )
{
  //we do not support probe
  //probe supports during initialization only
  return SNS_DDF_SUCCESS;
}

sns_ddf_status_e sns_dd_lsm6dsm_hub_init(
    sns_ddf_handle_t* dd_handle,
    sns_ddf_handle_t smgr_handle,
    sns_ddf_nv_params_s* nv_params,
    sns_ddf_device_access_s device_info[],
    uint32_t num_devices,
    sns_ddf_memhandler_s* memhandler,
    sns_ddf_sensor_e* sensors[],
    uint32_t* num_sensors)
{
  //probe the sensor
  //if sensor is not present
  //return init failed
  //dd_handle is already updated, so dereference 
  sns_dd_lsm6dsm_state_t* state = sns_dd_lsm6dsm_get_state(*dd_handle);
  uint8_t value = 0;
  channel_read_info_t read_info;
  LSM6DSM_MSG_0(LOW, "HUB_INIT:: ");
  sns_dd_lsm6dsm_hub_reset(*dd_handle);
  read_info.src_cond = false;
  sns_ddf_lsm6dsm_rwSlaveRegister(*dd_handle, STM_LSM6DSM_SLAVE_1_WAI_REG_ADDR, STM_LSM6DSM_HUB_READ_ONCE_OP, &read_info, &value, 1);
  if(value != STM_LSM6DSM_SLAVE_1_WAI_ID) {
    LSM6DSM_MSG_2(LOW, "HUB_INIT:: wrong ID %d expected Id %d",value, STM_LSM6DSM_SLAVE_1_WAI_ID);
    return SNS_DDF_EFAIL;
  }
  sns_ddf_axes_map_init(&state->hub_info.axes_map,
      ((nv_params != NULL) ? nv_params->data : stm_lsm6dsm_slv_axis_dflt));
  return SNS_DDF_SUCCESS;
}


/**
 * @brief Retrieves the value of an attribute for a lsm6dsm sensor.
 *
 * Refer to sns_ddf_driver_if.h for definition.
 */
sns_ddf_status_e sns_dd_lsm6dsm_hub_get_attr(
    sns_ddf_handle_t dd_handle,
    sns_ddf_sensor_e sensor,
    sns_ddf_attribute_e attrib,
    sns_ddf_memhandler_s* memhandler,
    void** value,
    uint32_t* num_elems)
{
  sns_dd_lsm6dsm_state_t *state;
  uint32_t sub_dev_idx;
  sns_ddf_sensor_e p_sensor;

  if (dd_handle == NULL || value == NULL) {
    LSM6DSM_MSG_E_0(ERROR, "dd_handle is NULL");
    return SNS_DDF_EINVALID_PARAM;
  }

  LSM6DSM_MSG_0(LOW, "HUB_GET_ATTRIB:: ");
  state = sns_dd_lsm6dsm_get_state(dd_handle);
  sub_dev_idx = ((stm_lsm6dsm_sub_dev_s*) dd_handle)->idx;
  p_sensor = state->sub_dev[sub_dev_idx].sensors[0]; // '0' --> Primary

  switch(attrib)
  {
    case SNS_DDF_ATTRIB_POWER_INFO:
      {
        sns_ddf_power_info_s* power = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler, sizeof(sns_ddf_power_info_s), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == power)
          return SNS_DDF_ENOMEM;
        //current consumption, unit uA
        power->active_current = 1800;
        power->lowpower_current = 3;

        *value = power;
        *num_elems = 1;
        return SNS_DDF_SUCCESS;
      }

    case SNS_DDF_ATTRIB_RANGE:
      {
        sns_ddf_range_s* ranges = NULL;
        ranges = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler, 1 * sizeof(sns_ddf_range_s),state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == ranges)
          return SNS_DDF_ENOMEM;
        ranges[0].min = STM_LSM6DSM_SLAVE_MIN_RANGE;
        ranges[0].max = STM_LSM6DSM_SLAVE_MAX_RANGE;

        *num_elems = 1;
        *value = ranges;
        return SNS_DDF_SUCCESS;
      }

    case SNS_DDF_ATTRIB_RESOLUTION:
      {
        sns_ddf_resolution_t *res = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler, sizeof(sns_ddf_resolution_t), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == res)
          return SNS_DDF_ENOMEM;
        *res = FX_FLTTOFIX_Q16(STM_LSM6DSM_SALVE_1_SSTVT);

        *value = res;
        *num_elems = 1;

        return SNS_DDF_SUCCESS;
      }

    case SNS_DDF_ATTRIB_RESOLUTION_ADC:
      {
        sns_ddf_resolution_adc_s *res = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler ,sizeof(sns_ddf_resolution_adc_s), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == res)
          return SNS_DDF_ENOMEM;

        res->bit_len = 16;
        res->max_freq = slave_odr[STM_LSM6DSM_SLAVE_ODR_NUM - 1];
        *value = res;
        *num_elems = 1;

        return SNS_DDF_SUCCESS;
      }
    case SNS_DDF_ATTRIB_SUPPORTED_ODR_LIST:
      {
        //TODO set odr list as one element of supporting odr
        *value = slave_odr;
        *num_elems = ARR_SIZE(slave_odr);
        return SNS_DDF_SUCCESS;
      }
    case SNS_DDF_ATTRIB_ODR:
      {
        //int8_t lsm6dsm_rate_index = -1;
        sns_ddf_odr_t *res = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler ,sizeof(sns_ddf_odr_t), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == res)
          return SNS_DDF_ENOMEM;
        *res = state->hub_info.cur_rate;
        LSM6DSM_MSG_2(LOW, "Get_ATTRIB_ODR sensor(%d) odr (%d)",sensor, *res);

        *value = res;
        *num_elems = 1;

        return SNS_DDF_SUCCESS;
      }
    case SNS_DDF_ATTRIB_DELAYS:
      {
        sns_ddf_delays_s *lsm6dsm_delays = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler, sizeof(sns_ddf_delays_s), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == lsm6dsm_delays)
          return SNS_DDF_ENOMEM;


        lsm6dsm_delays->time_to_active = 100;
        lsm6dsm_delays->time_to_data = 1;
        *value = lsm6dsm_delays;
        *num_elems = 1;

        return SNS_DDF_SUCCESS;
      }
#if 0
   case SNS_DDF_ATTRIB_BIAS:
      {
        *value = state->hub_info.biases;
        *num_elems = ARR_SIZE(state->hub_info.biases);

        return SNS_DDF_SUCCESS;
      }
#endif
     case SNS_DDF_ATTRIB_FIFO:
      {
        sns_ddf_status_e status;
        sns_ddf_fifo_share_sensor_s shared_sensors_fifo[STM_LSM6DSM_MAX_SHARED_FIFO_SENSORS];
        uint8_t size = STM_LSM6DSM_MAX_SHARED_FIFO_SENSORS;
        sns_ddf_fifo_share_sensor_s* dd_shared_sensors = NULL;
        uint8_t i = 0;

        sns_ddf_fifo_attrib_get_s *res = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler ,sizeof(sns_ddf_fifo_attrib_get_s), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == res)
          return SNS_DDF_ENOMEM;

        res->share_sensors[0] = NULL;
        res->is_supported = true;
        res->is_sw_watermark = false;
        res->max_watermark = STM_LSM6DSM_MAX_FIFO;
        status = sns_dd_lsm6dsm_sharedFifo_info(dd_handle, sensor, shared_sensors_fifo, &size);
        if(status == SNS_DDF_SUCCESS) {
          dd_shared_sensors = sns_dd_lsm6dsm_memhandler_malloc(
              memhandler , size * sizeof(sns_ddf_fifo_share_sensor_s), state->sub_dev[sub_dev_idx].smgr_handle);
          if(NULL == dd_shared_sensors)
            return SNS_DDF_ENOMEM;
          for(i = 0; i < size; i++) {
            dd_shared_sensors[i].sensor = shared_sensors_fifo[i].sensor;
            dd_shared_sensors[i].dd_handle = shared_sensors_fifo[i].dd_handle;
          }
          res->share_sensors[0] = dd_shared_sensors;
        }
        *value = res;
        *num_elems = 1;
        return status;
      }
#if 0
    case SNS_DDF_ATTRIB_ODR_TOLERANCE:
      {
        q16_t *res = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler ,sizeof(q16_t), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == res)
          return SNS_DDF_ENOMEM;
        if(sensor == SNS_DDF_SENSOR_ACCEL)
        {
          *res = FX_FLTTOFIX_Q16(0.05);
        }
        else if(sensor == SNS_DDF_SENSOR_GYRO)
        {
          *res = FX_FLTTOFIX_Q16(0.05);
        }
        else
        {
          LSM6DSM_MSG_E_1(ERROR, " Invalid sensor (%d) ", sensor);
          return SNS_DDF_EINVALID_ATTR;
        }
        *value = res;
        *num_elems = 1;

        return SNS_DDF_SUCCESS;
      }
#endif
    case SNS_DDF_ATTRIB_DEVICE_INFO:
      {
        sns_ddf_device_info_s *info = sns_dd_lsm6dsm_memhandler_malloc(
            memhandler, sizeof(sns_ddf_device_info_s), state->sub_dev[sub_dev_idx].smgr_handle);
        if(NULL == info)
          return SNS_DDF_ENOMEM;
        info->name = STM_LSM6DSM_SLAVE_SENSOR_NAME;
        info->vendor = STM_LSM6DSM_SLAVE_SENSOR_VENDOR;
        info->model = STM_LSM6DSM_SLAVE_SENSOR_MODEL;
        info->version = 1;
        *value = info;
        *num_elems = 1;

        return SNS_DDF_SUCCESS;
      }
    default:
      return SNS_DDF_EINVALID_ATTR;
  }
}

/**
 * @brief Sets a lsm6dsm sensor attribute to a specific value.
 *
 * Refer to sns_ddf_driver_if.h for definition.
 */
sns_ddf_status_e sns_dd_lsm6dsm_hub_set_attr(
    sns_ddf_handle_t dd_handle,
    sns_ddf_sensor_e sensor,
    sns_ddf_attribute_e attrib,
    void* value)
{
  uint32_t sub_dev_idx;
  sns_ddf_status_e  status = SNS_DDF_SUCCESS;
  sns_ddf_sensor_e ddf_sensor_type;

  if (dd_handle == NULL || value == NULL) {
    LSM6DSM_MSG_E_0(ERROR, "dd_handle is NULL");
    return SNS_DDF_EINVALID_PARAM;
  }

  LSM6DSM_MSG_0(LOW, "HUB_SET_ATTRIB:: ");
  sns_dd_lsm6dsm_state_t* state = sns_dd_lsm6dsm_get_state(dd_handle);
  sub_dev_idx = ((stm_lsm6dsm_sub_dev_s*) dd_handle)->idx;
  ddf_sensor_type = state->sub_dev[sub_dev_idx].sensors[0]; // '0' --> Primary

  switch(attrib)
  {
    case SNS_DDF_ATTRIB_POWER_STATE:
      {
        sns_ddf_powerstate_e* power_state = value;

        LSM6DSM_MSG_3(LOW, "SET_POWER - sensor (%d) sub_dev_idx (%d) value (%d)", sensor, sub_dev_idx, *power_state);

        if ((SNS_DDF_POWERSTATE_LOWPOWER == *power_state)
            &&(SNS_DDF_POWERSTATE_ACTIVE == state->sub_dev[sub_dev_idx].powerstate)) {
          if(state->hub_info.cur_rate) {
            sns_ddf_lsm6dsm_hub_set_slaveRate(dd_handle, 0, 0);
          }
          if(state->fifo_info.fifo_int_enabled & SLAVE_FIFO_BM)
            sns_dd_lsm6dsm_disable_fifo_int(dd_handle, LSM6DSM_SLAVE_SENSOR);
          if(state->fifo_info.fifo_enabled & SLAVE_FIFO_BM)
            sns_dd_lsm6dsm_disable_fifo(dd_handle, LSM6DSM_SLAVE_SENSOR);
          state->sub_dev[sub_dev_idx].powerstate = SNS_DDF_POWERSTATE_LOWPOWER;
        } else if ((SNS_DDF_POWERSTATE_ACTIVE == *power_state)
            &&(SNS_DDF_POWERSTATE_LOWPOWER == state->sub_dev[sub_dev_idx].powerstate)) {
          state->sub_dev[sub_dev_idx].powerstate = SNS_DDF_POWERSTATE_ACTIVE;
        }
        break;
      }
    case SNS_DDF_ATTRIB_RANGE:
      {
        state->hub_info.sstvt = STM_LSM6DSM_SALVE_1_SSTVT; //sensitivity(gauss/LSB) in float
        return SNS_DDF_SUCCESS;
      }

    case SNS_DDF_ATTRIB_ODR:
      {
        int i;
        sns_ddf_status_e status = SNS_DDF_SUCCESS;
        sns_ddf_odr_t desired_odr = *(sns_ddf_odr_t*)value;
        if (desired_odr == 0) {
          status = sns_ddf_lsm6dsm_hub_set_slaveRate(dd_handle, 0, 0);
        } else {
          for (i = 0; i < STM_LSM6DSM_SLAVE_ODR_NUM; i++)
            if (desired_odr <= slave_odr[i])
              break;
          if (i >= STM_LSM6DSM_SLAVE_ODR_NUM) {
            status = SNS_DDF_EINVALID_PARAM;
          } else
            status = sns_ddf_lsm6dsm_hub_set_slaveRate(dd_handle, slave_odr[i], i);
        }
        return status;
      }
    case SNS_DDF_ATTRIB_FIFO:
      {
        sns_ddf_fifo_set_s* fifo = value;

        if(0 == fifo->watermark) {
          status = sns_dd_lsm6dsm_disable_fifo(dd_handle, sensor);
        }else if(fifo->watermark <= STM_LSM6DSM_MAX_FIFO) {
          //atleast acc should be up and running
          //if (state->acc_desired_rate_idx < 0)
          //  return SNS_DDF_EFAIL;

          status = sns_dd_lsm6dsm_enable_fifo(dd_handle, fifo->watermark, sensor);
        } else {
          status = SNS_DDF_EINVALID_ATTR;
        }

        break;
      }

    default:
      status = SNS_DDF_EINVALID_ATTR;
  }
  return status;
}

/**
 * LSM6DSMLHC device driver interface.
 */
sns_ddf_driver_if_s sns_dd_lsm6dsm_hub_if =
{
  &sns_dd_lsm6dsm_hub_init,
  NULL,
  &sns_dd_lsm6dsm_hub_set_attr,
  &sns_dd_lsm6dsm_hub_get_attr,
  NULL,
  NULL,
  &sns_dd_lsm6dsm_hub_reset,
  NULL,
  NULL,
  NULL,
  NULL
};
#endif
